McConnell Manor ReadMe

PREREQUISITES:
Your character must have completed the quest "When Freedom Calls" where you help Preston Garvey and the minutemen in Concord. If you have not, you can use the following console command:
	- SetStage DialogueConcordArea 200
You will have to leave the area and then come back (coc to a different exterior cell and then continue with the instructions below)

*Optional: There are two chances in the Ghost, Interrupted quest to convince Jedediah of seomthing. This requires the player to have a high enough charisma level to pass an easy speech challenge. However, this is not required to complete either quest.


STARTING THE "MCCONNELL MANOR" QUEST
- COC to ConcordMuseumExt

- From the Museum of Freedom entrance, head down the northwest street. Go all the way to the end of the street and at the Bank building, turn right. Continue along that street until you see a black and gray building that is the Sheriff's Office on your right hand side (it has a "Police" sign on the building

- Read the note on the bulletin board next to the door of the Sheriff's Office to begin the quest (you may also just enter the office and speak to the sheriff yourself and bypass the note)


STARTING THE "GHOST, INTERRUPTED" QUEST
- Speak to Jedediah McConnell's Ghost in one of the upstairs bedrooms (you should naturally find him by exploring the rooms of the manor looking for the attic key)

- To complete this quest (and subsequently get the attic key) you need to put all the items back in their correct dressers. The items have been scattered in the rooms in the bottom floor of the manor.
	SOLUTION:
		1) Ann: The "Cherished Cake Pan" can be found on the counter top in the kitchen (The door immediately to your left on entering the manor).
		2) Isiaah: The "Favoured Bourbon Bottle" can be found on the circular table on the eastern side of the sitting room (This is the downstairs room with the fireplace and chairs).
		3) Hester: The "Well Loved Book" can be found on the circular table in the library (Exiting the eastern door of the sitting room, the library is the door directly across the hall).

- Once you put the items in the dresser, speak to Jedediah again and he will tell you where the attic key is so you can continue the McConnell Manor Quest


